"""Mr. Islam OpenBoard build step: prepare the emoji pictures.

Usage: python make_emoji.py <emoji-manifest.txt> <noto-emoji checkout> <output folder>

Takes the Noto Emoji 3D pictures (512 px, Apache License 2.0) listed in the manifest,
resizes them to 256 px and writes them with manifest.txt into the output folder.
The program reads <program folder>/emoji/manifest.txt at run time.
"""
import os
import shutil
import sys
from multiprocessing import Pool

from PIL import Image

SIZE = 256


def convert(job):
    src, dst = job

    if not os.path.isfile(src):
        return False

    image = Image.open(src).convert("RGBA")
    if image.size != (SIZE, SIZE):
        image = image.resize((SIZE, SIZE), Image.LANCZOS)
    image.save(dst, "PNG", optimize=True)
    return True


def main():
    manifest, noto, out = sys.argv[1], sys.argv[2], sys.argv[3]
    src_dir = os.path.join(noto, "3D", "png", "512")
    os.makedirs(out, exist_ok=True)

    lines = [l.rstrip("\n") for l in open(manifest, encoding="utf-8") if l.strip()]
    jobs = [(os.path.join(src_dir, l.split("\t")[1]), os.path.join(out, l.split("\t")[1])) for l in lines]

    with Pool() as pool:
        results = pool.map(convert, jobs, chunksize=16)

    missing = [os.path.basename(src) for (src, _), ok in zip(jobs, results) if not ok]

    shutil.copyfile(manifest, os.path.join(out, "manifest.txt"))

    for extra in ("LICENSE",):
        path = os.path.join(noto, extra)
        if os.path.isfile(path):
            shutil.copyfile(path, os.path.join(out, "NOTO-EMOJI-LICENSE.txt"))

    print(f"emoji ready: {len(lines) - len(missing)} of {len(lines)}")

    if missing:
        print("missing:", ", ".join(missing[:20]))
        # a few missing pictures must not stop the build, but almost all must be there
        if len(missing) > 20:
            sys.exit(1)


if __name__ == "__main__":
    main()
