/*
 * Copyright (C) 2026 Mr. Islam Elmasry customization of OpenBoard
 *
 * This file is part of OpenBoard.
 *
 * OpenBoard is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License,
 * with a specific linking exception for the OpenSSL project's
 * "OpenSSL" library (or with modified versions of it that use the
 * same license as the "OpenSSL" library).
 *
 * OpenBoard is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenBoard. If not, see <http://www.gnu.org/licenses/>.
 */

#include "UBExternalCalculator.h"

#include <QDir>
#include <QDirIterator>
#include <QFileDialog>
#include <QFileInfo>
#include <QMessageBox>
#include <QStringList>

#include "core/UBSettings.h"

#ifdef Q_OS_WIN
#include <windows.h>
#endif

namespace
{
    const char* kPathKey = "App/MrIslamCalculatorPath";

#ifdef Q_OS_WIN
    struct FindWindowData
    {
        DWORD pid;
        HWND hwnd;
    };

    // finds the visible main window of the emulator: by process id, or by its title
    BOOL CALLBACK findCalculatorWindow(HWND hwnd, LPARAM lParam)
    {
        FindWindowData* data = reinterpret_cast<FindWindowData*>(lParam);

        if (!IsWindowVisible(hwnd) || GetWindow(hwnd, GW_OWNER) != nullptr)
            return TRUE;

        wchar_t buffer[256] = { 0 };
        GetWindowTextW(hwnd, buffer, 255);
        const QString title = QString::fromWCharArray(buffer);

        if (title.isEmpty())
            return TRUE;

        DWORD pid = 0;
        GetWindowThreadProcessId(hwnd, &pid);

        const bool sameProcess = data->pid != 0 && pid == data->pid;
        const bool emulatorTitle = title.contains("fx-", Qt::CaseInsensitive)
                && title.contains("Emulator", Qt::CaseInsensitive);

        if (sameProcess || emulatorTitle)
        {
            data->hwnd = hwnd;
            return FALSE; // stop searching
        }

        return TRUE;
    }
#endif
}

UBExternalCalculator::UBExternalCalculator(QObject* parent)
    : QObject(parent)
    , mProcess(new QProcess(this))
{
    mWatchTimer.setInterval(300);
    connect(&mWatchTimer, &QTimer::timeout, this, &UBExternalCalculator::watch);
}

UBExternalCalculator::~UBExternalCalculator()
{
    // leave the emulator running if OpenBoard closes: do not kill it
    if (mProcess->state() != QProcess::NotRunning)
    {
        mProcess->setParent(nullptr);
    }
}

void UBExternalCalculator::toggle()
{
    if (mOpen)
        close();
    else
        open();
}

void UBExternalCalculator::chooseProgram()
{
    const QString path = askForProgram();

    if (!path.isEmpty())
    {
        if (mOpen)
            close();

        open();
    }
}

void UBExternalCalculator::open()
{
    const QString program = programPath();

    if (program.isEmpty())
    {
        setOpen(false);
        return;
    }

    mProcess->setProgram(program);
    mProcess->setWorkingDirectory(QFileInfo(program).absolutePath());
    mProcess->start();

    if (!mProcess->waitForStarted(5000))
    {
        UBSettings::settings()->setValue(kPathKey, QString());
        QMessageBox::warning(nullptr, tr("Calculator"),
                             tr("The calculator could not be started:\n%1\n\nClick the Calculator button again to choose the program.")
                             .arg(QDir::toNativeSeparators(program)));
        setOpen(false);
        return;
    }

    mWindow = 0;
    mTicks = 0;
    setOpen(true);
    mWatchTimer.start();
}

void UBExternalCalculator::close()
{
#ifdef Q_OS_WIN
    if (mWindow && IsWindow(reinterpret_cast<HWND>(mWindow)))
        PostMessageW(reinterpret_cast<HWND>(mWindow), WM_CLOSE, 0, 0);
#endif

    if (mProcess->state() != QProcess::NotRunning)
        mProcess->terminate(); // asks the program to close its windows

    mWatchTimer.stop();
    mWindow = 0;
    setOpen(false);
}

void UBExternalCalculator::watch()
{
    ++mTicks;

#ifdef Q_OS_WIN
    HWND hwnd = reinterpret_cast<HWND>(mWindow);

    if (hwnd && !IsWindow(hwnd))
    {
        // closed with its own X button
        mWatchTimer.stop();
        mWindow = 0;
        setOpen(false);
        return;
    }

    if (!hwnd)
    {
        FindWindowData data;
        data.pid = mProcess->state() != QProcess::NotRunning ? static_cast<DWORD>(mProcess->processId()) : 0;
        data.hwnd = nullptr;
        EnumWindows(findCalculatorWindow, reinterpret_cast<LPARAM>(&data));
        hwnd = data.hwnd;
        mWindow = reinterpret_cast<quintptr>(hwnd);
    }

    if (hwnd)
    {
        // keep it above the board (also when OpenBoard is full screen), without stealing the focus
        SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);

        if (mWatchTimer.interval() != 1000)
            mWatchTimer.setInterval(1000);

        return;
    }

    // window not found after ~15 seconds and the program is gone: consider it closed
    if (mTicks > 50 && mProcess->state() == QProcess::NotRunning)
    {
        mWatchTimer.stop();
        setOpen(false);
    }
#else
    if (mProcess->state() == QProcess::NotRunning)
    {
        mWatchTimer.stop();
        setOpen(false);
    }
#endif
}

QString UBExternalCalculator::programPath()
{
    QString path = UBSettings::settings()->value(kPathKey, QString()).toString();

    if (!path.isEmpty() && QFileInfo::exists(path))
        return path;

    path = findInstalledProgram();

    if (!path.isEmpty())
    {
        UBSettings::settings()->setValue(kPathKey, path);
        return path;
    }

    return askForProgram();
}

QString UBExternalCalculator::findInstalledProgram() const
{
    QStringList shortcutFolders;
    shortcutFolders << qEnvironmentVariable("ProgramData") + "/Microsoft/Windows/Start Menu/Programs"
                    << qEnvironmentVariable("APPDATA") + "/Microsoft/Windows/Start Menu/Programs";

    QStringList programFolders;
    programFolders << qEnvironmentVariable("ProgramFiles(x86)") + "/CASIO"
                   << qEnvironmentVariable("ProgramFiles") + "/CASIO";

    QString fallback;

    // 1. Start menu shortcuts named like "fx-991ES PLUS ..."
    for (const QString& folder : shortcutFolders)
    {
        if (folder.startsWith('/') || !QDir(folder).exists())
            continue;

        QDirIterator it(folder, QStringList() << "*991*.lnk", QDir::Files, QDirIterator::Subdirectories);

        while (it.hasNext())
        {
            const QString target = resolveShortcut(it.next());

            if (target.endsWith(".exe", Qt::CaseInsensitive) && QFileInfo::exists(target))
            {
                if (QFileInfo(it.filePath()).fileName().contains("ES", Qt::CaseSensitive))
                    return target;

                if (fallback.isEmpty())
                    fallback = target;
            }
        }
    }

    if (!fallback.isEmpty())
        return fallback;

    // 2. the program itself in the CASIO install folder
    for (const QString& folder : programFolders)
    {
        if (folder.startsWith('/') || !QDir(folder).exists())
            continue;

        QDirIterator it(folder, QStringList() << "*991*.exe", QDir::Files, QDirIterator::Subdirectories);

        while (it.hasNext())
        {
            const QString exe = it.next();

            if (QFileInfo(exe).fileName().contains("ES", Qt::CaseSensitive))
                return exe;

            if (fallback.isEmpty())
                fallback = exe;
        }
    }

    return fallback;
}

QString UBExternalCalculator::askForProgram()
{
    QString startFolder = qEnvironmentVariable("ProgramFiles(x86)") + "/CASIO";

    if (!QDir(startFolder).exists())
        startFolder = qEnvironmentVariable("ProgramData") + "/Microsoft/Windows/Start Menu/Programs";

    QString path = QFileDialog::getOpenFileName(nullptr,
                                                tr("Choose the calculator program (fx-991ES PLUS Emulator)"),
                                                startFolder,
                                                tr("Programs (*.exe *.lnk)"));

    if (path.isEmpty())
        return QString();

    path = resolveShortcut(path);
    UBSettings::settings()->setValue(kPathKey, path);
    return path;
}

QString UBExternalCalculator::resolveShortcut(const QString& path)
{
    const QFileInfo info(path);

    if (path.endsWith(".lnk", Qt::CaseInsensitive))
    {
        const QString target = info.symLinkTarget(); // Windows shortcuts are resolved by Qt

        if (!target.isEmpty())
            return target;
    }

    return info.absoluteFilePath();
}

void UBExternalCalculator::setOpen(bool open)
{
    mOpen = open;
    emit openChanged(open);
}
