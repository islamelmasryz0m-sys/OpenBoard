/*
 * Copyright (C) 2026 Mr. Islam Elmasry customization of OpenBoard
 *
 * This file is part of OpenBoard.
 *
 * OpenBoard is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License,
 * with a specific linking exception for the OpenSSL project's
 * "OpenSSL" library (or with modified versions of it that use the
 * same license as the "OpenSSL" library).
 *
 * OpenBoard is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenBoard. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef UBEXTERNALCALCULATOR_H_
#define UBEXTERNALCALCULATOR_H_

#include <QObject>
#include <QProcess>
#include <QString>
#include <QTimer>

/**
 * Opens and closes the calculator emulator installed on the computer
 * (for example the CASIO fx-991ES PLUS Emulator) from the OpenBoard toolbar,
 * and keeps its window above the board so it shows in screen sharing and recordings.
 *
 * The first time, the program is searched in the usual install folders;
 * if it is not found the teacher picks it once (.exe or Start menu shortcut).
 */
class UBExternalCalculator : public QObject
{
    Q_OBJECT

public:
    explicit UBExternalCalculator(QObject* parent = nullptr);
    ~UBExternalCalculator() override;

    bool isOpen() const { return mOpen; }

public slots:
    void toggle();
    void open();
    void close();
    void chooseProgram();

signals:
    void openChanged(bool open);

private slots:
    void watch();

private:
    QString programPath();
    QString findInstalledProgram() const;
    QString askForProgram();
    static QString resolveShortcut(const QString& path);
    void setOpen(bool open);

    QProcess* mProcess;
    QTimer mWatchTimer;
    quintptr mWindow{0};
    int mTicks{0};
    bool mOpen{false};
};

#endif /* UBEXTERNALCALCULATOR_H_ */
