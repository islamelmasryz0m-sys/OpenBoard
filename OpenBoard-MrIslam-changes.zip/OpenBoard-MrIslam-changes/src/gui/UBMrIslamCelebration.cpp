/*
 * Mr. Islam El-Masry: "correct answer" celebration for OpenBoard.
 *
 * This file is part of OpenBoard (GPL v3).
 *
 * The 100 picture comes from the Noto Emoji set shipped next to the program (Apache License 2.0),
 * the pop-up pictures are Mr. Islam's own stickers, the sounds are the two recordings he chose.
 */

#include "UBMrIslamCelebration.h"

#include <QApplication>
#include <QDir>
#include <QEvent>
#include <QFileInfo>
#include <QPainter>
#include <QPainterPath>
#include <QRandomGenerator>
#include <QSoundEffect>
#include <QUrl>

#include <cmath>

#include "core/UBSettings.h"

namespace
{
    const int kFrameMs = 33;              // about 30 frames per second, light for the board below
    const int kPopMs = 2400;              // sticker pop-up time
    const char* const kSoundKey = "Board/MrIslamCelebrateSound";
    const qreal kTwoPi = 6.283185307179586;

    qreal rnd(qreal a, qreal b)
    {
        return a + QRandomGenerator::global()->generateDouble() * (b - a);
    }

    int pickIndex(int count)
    {
        return count > 0 ? int(QRandomGenerator::global()->bounded(count)) : 0;
    }

    const QList<QColor>& confettiColors()
    {
        static const QList<QColor> colors {
            QColor("#E61B1B"), QColor("#FF5500"), QColor("#FFCE00"), QColor("#26E600"),
            QColor("#004DE6"), QColor("#6600CC"), QColor("#FF80FF"), QColor("#00AACC") };
        return colors;
    }

    const QList<QColor>& starColors()
    {
        static const QList<QColor> colors { QColor("#FFD54F"), QColor("#FFC107"), QColor("#FFE082"), QColor("#FFB300") };
        return colors;
    }

    // smooth pop: grows with a small bounce, stays, then shrinks away
    void popShape(qreal t, qreal& scale, qreal& opacity, qreal& lift)
    {
        lift = 0;
        if (t < 0.14) { qreal k = t / 0.14; scale = 1.18 * k; opacity = k; }
        else if (t < 0.24) { qreal k = (t - 0.14) / 0.10; scale = 1.18 - 0.22 * k; opacity = 1; }
        else if (t < 0.32) { qreal k = (t - 0.24) / 0.08; scale = 0.96 + 0.04 * k; opacity = 1; }
        else if (t < 0.80) { scale = 1.0; opacity = 1; }
        else { qreal k = (t - 0.80) / 0.20; scale = 1.0 - 0.4 * k; opacity = 1 - k; lift = 40 * k; }
    }
}

UBMrIslamCelebration::UBMrIslamCelebration(QWidget* board)
    : QWidget(board)
{
    setAttribute(Qt::WA_TransparentForMouseEvents, true);
    setAttribute(Qt::WA_NoSystemBackground, true);
    setAutoFillBackground(false);
    setFocusPolicy(Qt::NoFocus);
    hide();

    if (board)
    {
        setGeometry(board->rect());
        board->installEventFilter(this);
    }

    mTimer.setInterval(kFrameMs);
    connect(&mTimer, &QTimer::timeout, this, &UBMrIslamCelebration::tick);

    // get the pictures and sounds ready a little after start-up, so the first celebration is instant
    QTimer::singleShot(4000, this, [this]() { loadAssets(); });
}

qreal UBMrIslamCelebration::stageWidth() const
{
    return mStage.isEmpty() ? QWidget::width() : mStage.width();
}

qreal UBMrIslamCelebration::stageHeight() const
{
    return mStage.isEmpty() ? QWidget::height() : mStage.height();
}

int UBMrIslamCelebration::soundMode()
{
    const int mode = UBSettings::settings()->value(kSoundKey, 3).toInt();
    return (mode >= 0 && mode <= 3) ? mode : 3;
}

void UBMrIslamCelebration::setSoundMode(int mode)
{
    UBSettings::settings()->setValue(kSoundKey, qBound(0, mode, 3));
}

bool UBMrIslamCelebration::eventFilter(QObject* watched, QEvent* event)
{
    if (watched == parentWidget() && event->type() == QEvent::Resize)
        setGeometry(parentWidget()->rect());

    return QWidget::eventFilter(watched, event);
}

void UBMrIslamCelebration::loadAssets()
{
    if (mAssetsLoaded)
        return;

    mAssetsLoaded = true;
    const QString appDir = QApplication::applicationDirPath();

    // praise stickers for the pop-up (the same ones as in the trial page)
    const QStringList praise { "01", "02", "04", "05", "06", "07", "09", "36" };

    for (const QString& n : praise)
    {
        QPixmap p(appDir + "/stickers/sticker-" + n + ".png");
        if (!p.isNull())
            mStickers << p;
    }

    if (mStickers.isEmpty())   // fall back to any sticker in the folder
    {
        const QFileInfoList files = QDir(appDir + "/stickers").entryInfoList({ "*.png" }, QDir::Files, QDir::Name);
        for (const QFileInfo& f : files)
        {
            QPixmap p(f.absoluteFilePath());
            if (!p.isNull())
                mStickers << p;
            if (mStickers.size() >= 8)
                break;
        }
    }

    mHundred = QPixmap(appDir + "/emoji/emoji_u1f4af.png");

    // the two sounds live inside the program (OpenBoard.qrc), so nothing extra has to be copied
    for (const QString& name : { QStringLiteral("mrislamCelebrate1.wav"), QStringLiteral("mrislamCelebrate2.wav") })
    {
        QSoundEffect* effect = new QSoundEffect(this);
        effect->setSource(QUrl(QStringLiteral("qrc:/mrislam/sounds/") + name));
        effect->setVolume(1.0);
        mSounds << effect;
    }
}

void UBMrIslamCelebration::playSound()
{
    const int mode = soundMode();

    if (mode == 0 || mSounds.isEmpty())
        return;

    int index = (mode == 3) ? pickIndex(mSounds.size()) : mode - 1;
    index = qBound(0, index, int(mSounds.size()) - 1);

    QSoundEffect* effect = mSounds.at(index);
    effect->stop();
    effect->play();
}

void UBMrIslamCelebration::celebrate()
{
    celebrateIn(QRect());
}

void UBMrIslamCelebration::celebrateIn(const QRect& stage)
{
    loadAssets();

    if (parentWidget())
        setGeometry(parentWidget()->rect());

    // the whole board, or only the Reels frame when it is on (so everything is seen inside the reel)
    mStage = stage.isValid() ? stage.intersected(rect()) : QRect();
    if (mStage.isEmpty())
        mStage = rect();

    show();
    raise();

    // a different effect each time (never the same one twice in a row)
    static int lastChoice = -1;
    int choice = pickIndex(4);
    if (choice == lastChoice)
        choice = (choice + 1 + pickIndex(3)) % 4;
    lastChoice = choice;

    switch (choice)
    {
        case 0: startConfetti(); break;
        case 1: startStars(); break;
        case 2: startFireworks(); break;
        default: startHundred(); break;
    }

    // a sticker pops up with every celebration except the golden 100 (that one is its own pop-up)
    if (choice != 3 && !mStickers.isEmpty())
    {
        mCurrentPop = mStickers.at(pickIndex(mStickers.size()));
        mPopIsHundred = false;
        mPopStart = 0;
    }

    mClock.restart();
    playSound();

    if (!mTimer.isActive())
        mTimer.start();
}

void UBMrIslamCelebration::startConfetti()
{
    const qreal w = stageWidth(), h = stageHeight();
    const qreal s = qBound<qreal>(1.0, h / 700.0, 2.2);

    for (int i = 0; i < 180; ++i)
    {
        const bool fromLeft = (i % 2) == 0;
        Particle p;
        p.kind = Confetti;
        p.pos = QPointF(fromLeft ? rnd(-10, w * 0.15) : rnd(w * 0.85, w + 10), h + 10);
        p.vel = QPointF(fromLeft ? rnd(2, 9) : rnd(-9, -2), rnd(-17, -10) * (h / 700.0 + 0.4)) * 2.0;
        p.gravity = 0.32 * 4.0;
        p.size = rnd(7, 13) * s;
        p.angle = rnd(0, kTwoPi);
        p.spin = rnd(-0.5, 0.5);
        p.twinkle = 0;
        p.color = confettiColors().at(pickIndex(confettiColors().size()));
        p.maxLife = p.life = int(rnd(75, 100));
        mParticles << p;
    }
}

void UBMrIslamCelebration::startStars()
{
    const qreal w = stageWidth(), h = stageHeight();
    const qreal s = qBound<qreal>(1.0, h / 700.0, 2.2);

    for (int i = 0; i < 70; ++i)
    {
        Particle p;
        p.kind = Star;
        p.pos = QPointF(rnd(0, w), rnd(-h * 0.6, -20));
        p.vel = QPointF(rnd(-0.6, 0.6), rnd(2.5, 5.5) * s) * 2.0;
        p.gravity = 0.02 * 4.0;
        p.size = rnd(9, 20) * s;
        p.angle = rnd(0, kTwoPi);
        p.spin = rnd(-0.12, 0.12);
        p.twinkle = rnd(0, 6);
        p.color = starColors().at(pickIndex(starColors().size()));
        p.maxLife = p.life = int(rnd(85, 115));
        mParticles << p;
    }
}

void UBMrIslamCelebration::addBurst(const QPointF& center, const QColor& color, int count)
{
    const qreal s = qBound<qreal>(1.0, stageHeight() / 700.0, 2.2);

    for (int i = 0; i < count; ++i)
    {
        const qreal a = kTwoPi * i / count;
        const qreal speed = rnd(2.5, 6.5) * s * 2.0;
        Particle p;
        p.kind = Spark;
        p.pos = center;
        p.vel = QPointF(std::cos(a) * speed, std::sin(a) * speed);
        p.gravity = 0.06 * 4.0;
        p.size = rnd(2, 3.6) * s;
        p.angle = 0;
        p.spin = 0;
        p.twinkle = 0;
        p.color = color;
        p.maxLife = p.life = int(rnd(30, 48));
        mParticles << p;
    }
}

void UBMrIslamCelebration::startFireworks()
{
    const qreal w = stageWidth(), h = stageHeight();

    for (int b = 0; b < 5; ++b)
    {
        mPendingBursts << qMakePair(b * 330, QPointF(rnd(w * 0.15, w * 0.85), rnd(h * 0.15, h * 0.45)));
        mPendingColors << confettiColors().at(pickIndex(confettiColors().size()));
    }
}

void UBMrIslamCelebration::startHundred()
{
    if (!mHundred.isNull())
    {
        mCurrentPop = mHundred;
        mPopIsHundred = true;
        mPopStart = 0;
    }

    const QPointF center(stageWidth() / 2.0, stageHeight() * 0.42);
    const qreal s = qBound<qreal>(1.0, stageHeight() / 700.0, 2.2);

    for (int i = 0; i < 45; ++i)
    {
        const qreal a = rnd(0, kTwoPi), speed = rnd(2, 7) * s * 2.0;
        Particle p;
        p.kind = Star;
        p.pos = center;
        p.vel = QPointF(std::cos(a) * speed, std::sin(a) * speed);
        p.gravity = 0.05 * 4.0;
        p.size = rnd(6, 12) * s;
        p.angle = 0;
        p.spin = rnd(-0.2, 0.2);
        p.twinkle = rnd(0, 6);
        QList<QColor> c { QColor("#FFD54F"), QColor("#FFC107"), QColor("#FFFFFF") };
        p.color = c.at(pickIndex(c.size()));
        p.maxLife = p.life = int(rnd(30, 50));
        mParticles << p;
    }
}

void UBMrIslamCelebration::tick()
{
    const int now = int(mClock.elapsed());

    // fireworks that are due now
    for (int i = mPendingBursts.size() - 1; i >= 0; --i)
    {
        if (mPendingBursts.at(i).first <= now)
        {
            addBurst(mPendingBursts.at(i).second, mPendingColors.at(i), 70);
            mPendingBursts.removeAt(i);
            mPendingColors.removeAt(i);
        }
    }

    const qreal h = stageHeight();

    for (int i = mParticles.size() - 1; i >= 0; --i)
    {
        Particle& p = mParticles[i];
        p.vel.setY(p.vel.y() + p.gravity);
        if (p.kind == Confetti)
            p.vel.setX(p.vel.x() * 0.98);
        p.pos += p.vel;
        p.angle += p.spin;
        p.twinkle += 0.4;
        p.life--;

        if (p.kind == Spark)
        {
            p.trail << p.pos;
            if (p.trail.size() > 4)
                p.trail.removeFirst();
        }

        if (p.life <= 0 || p.pos.y() > h + 80)
            mParticles.removeAt(i);
    }

    const bool popRunning = mPopStart >= 0 && now - mPopStart < kPopMs;

    if (mParticles.isEmpty() && mPendingBursts.isEmpty() && !popRunning)
    {
        mTimer.stop();
        mPopStart = -1;
        mCurrentPop = QPixmap();
        hide();
        return;
    }

    update();
}

static void drawStar(QPainter& painter, const QPointF& c, qreal r, qreal angle, const QColor& color)
{
    QPainterPath path;
    for (int i = 0; i < 10; ++i)
    {
        const qreal a = -kTwoPi / 4 + i * kTwoPi / 10 + angle;
        const qreal rr = (i % 2) ? r * 0.45 : r;
        const QPointF pt(c.x() + std::cos(a) * rr, c.y() + std::sin(a) * rr);
        if (i == 0)
            path.moveTo(pt);
        else
            path.lineTo(pt);
    }
    path.closeSubpath();
    painter.setPen(QPen(QColor(160, 110, 0, 150), 1.5));
    painter.setBrush(color);
    painter.drawPath(path);
}

void UBMrIslamCelebration::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    painter.setClipRect(mStage);
    painter.translate(mStage.topLeft());
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setRenderHint(QPainter::SmoothPixmapTransform, true);

    for (const Particle& p : std::as_const(mParticles))
    {
        painter.setOpacity(qBound<qreal>(0.0, p.life / 20.0, 1.0));

        if (p.kind == Confetti)
        {
            painter.save();
            painter.translate(p.pos);
            painter.rotate(p.angle * 57.2958);
            painter.scale(1.0, std::fabs(std::cos(p.angle * 2)) * 0.8 + 0.2);
            painter.fillRect(QRectF(-p.size / 2, -p.size * 0.7, p.size, p.size * 1.4), p.color);
            painter.restore();
        }
        else if (p.kind == Star)
        {
            drawStar(painter, p.pos, p.size * (0.85 + 0.15 * std::sin(p.twinkle)), p.angle, p.color);
        }
        else if (p.trail.size() > 1)
        {
            QPen pen(p.color, p.size, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
            painter.setPen(pen);
            painter.setBrush(Qt::NoBrush);
            QPainterPath path(p.trail.first());
            for (int k = 1; k < p.trail.size(); ++k)
                path.lineTo(p.trail.at(k));
            painter.drawPath(path);
        }
    }

    // the sticker / golden 100 pop-up
    if (mPopStart >= 0 && !mCurrentPop.isNull())
    {
        const qreal t = qBound<qreal>(0.0, (mClock.elapsed() - mPopStart) / qreal(kPopMs), 1.0);
        qreal scale, opacity, lift;
        popShape(t, scale, opacity, lift);

        const qreal base = mPopIsHundred ? qMin(stageWidth() * 0.5, stageHeight() * 0.30) : qMin(stageWidth() * 0.62, stageHeight() * 0.48);
        const qreal side = base * scale;
        const QPointF center(stageWidth() / 2.0, (mPopIsHundred ? stageHeight() * 0.42 : stageHeight() / 2.0) - lift);

        if (side > 1)
        {
            painter.setOpacity(opacity);
            const qreal ratio = mCurrentPop.height() / qreal(qMax(1, mCurrentPop.width()));
            const QRectF target(center.x() - side / 2, center.y() - side * ratio / 2, side, side * ratio);
            painter.drawPixmap(target, mCurrentPop, QRectF(mCurrentPop.rect()));
        }
    }
}
