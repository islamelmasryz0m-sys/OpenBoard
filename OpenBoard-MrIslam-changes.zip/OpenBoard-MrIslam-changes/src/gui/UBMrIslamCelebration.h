/*
 * Mr. Islam El-Masry: "correct answer" celebration for OpenBoard.
 *
 * This file is part of OpenBoard (GPL v3).
 */

#ifndef UBMRISLAMCELEBRATION_H_
#define UBMRISLAMCELEBRATION_H_

#include <QElapsedTimer>
#include <QList>
#include <QPixmap>
#include <QPointF>
#include <QStringList>
#include <QTimer>
#include <QWidget>

class QSoundEffect;

// A see-through layer over the board (inside the OpenBoard window, so screen sharing and recording see it).
// It plays one short celebration: confetti, falling stars, fireworks or a golden 100,
// plus a sticker that pops up in the middle and a short sound. Mouse and pen go straight through it.
// Nothing is added to the page: the document and exported PDFs are not touched.
class UBMrIslamCelebration : public QWidget
{
    Q_OBJECT

public:
    explicit UBMrIslamCelebration(QWidget* board);

    // 0 = no sound, 1 = first sound, 2 = second sound, 3 = random
    static int soundMode();
    static void setSoundMode(int mode);

public slots:
    void celebrate();
    void celebrateIn(const QRect& stage);   // stage = part of the board to use (the Reels frame when it is on)

protected:
    void paintEvent(QPaintEvent* event) override;
    bool eventFilter(QObject* watched, QEvent* event) override;

private slots:
    void tick();

private:
    enum Kind { Confetti, Star, Spark };

    struct Particle
    {
        Kind kind;
        QPointF pos;
        QPointF vel;
        qreal gravity;
        qreal size;
        qreal angle;
        qreal spin;
        qreal twinkle;
        QColor color;
        int life;
        int maxLife;
        QList<QPointF> trail;
    };

    void startConfetti();
    void startStars();
    void startFireworks();
    void startHundred();
    void addBurst(const QPointF& center, const QColor& color, int count);
    void playSound();
    void loadAssets();
    qreal stageWidth() const;
    qreal stageHeight() const;

    QTimer mTimer;
    QElapsedTimer mClock;
    QList<Particle> mParticles;
    QList<QPair<int, QPointF>> mPendingBursts;   // time in ms, centre
    QList<QColor> mPendingColors;

    QList<QPixmap> mStickers;
    QPixmap mHundred;
    QPixmap mCurrentPop;
    bool mPopIsHundred{false};
    int mPopStart{-1};

    QList<QSoundEffect*> mSounds;
    bool mAssetsLoaded{false};
    QRect mStage;
};

#endif /* UBMRISLAMCELEBRATION_H_ */
