/*
 * Mr. Islam El-Masry: pen size slider panel for OpenBoard.
 *
 * This file is part of OpenBoard (GPL v3).
 */

#include "UBMrIslamPenSizePanel.h"

#include <QGuiApplication>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QPainterPath>
#include <QScreen>
#include <QSlider>
#include <QVBoxLayout>

#include <cmath>

// preview line drawn with the chosen size and colour
class UBMrIslamPenSizePreview : public QWidget
{
public:
    explicit UBMrIslamPenSizePreview(QWidget* parent = nullptr) : QWidget(parent)
    {
        setMinimumHeight(70);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    }

    void setSize(int size)
    {
        mSize = size;
        update();
    }

    void set(int size, const QColor& color)
    {
        mSize = size;
        mColor = color;
        update();
    }

protected:
    void paintEvent(QPaintEvent*) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);

        const qreal margin = 20;
        const qreal w = width() - 2 * margin;
        const qreal amplitude = qMax<qreal>(2.0, qMin<qreal>(18.0, height() / 2.0 - mSize / 2.0 - 4));

        QPainterPath path;
        for (int i = 0; i <= 100; ++i)
        {
            const qreal x = margin + w * i / 100.0;
            const qreal y = height() / 2.0 + std::sin(i / 100.0 * 6.283185307179586) * amplitude;
            if (i == 0)
                path.moveTo(x, y);
            else
                path.lineTo(x, y);
        }

        QColor color = mColor;
        if (!color.isValid())
            color = Qt::black;

        QPen pen(color, mSize, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
        painter.setPen(pen);
        painter.drawPath(path);

        painter.setPen(QPen(QColor("#ECECEC"), 1));
        painter.drawLine(QPointF(8, height() - 1), QPointF(width() - 8, height() - 1));
    }

private:
    int mSize{6};
    QColor mColor{Qt::black};
};

UBMrIslamPenSizePanel::UBMrIslamPenSizePanel(QWidget* parent)
    : QFrame(parent, Qt::Popup | Qt::FramelessWindowHint)
{
    setObjectName("MrIslamPenSizePanel");
    setStyleSheet(
        "QFrame#MrIslamPenSizePanel { background: #FFFFFF; border: 1px solid #BDBDBD; border-radius: 10px; }"
        "QLabel#MrIslamPenSizeTitle { font-size: 15px; font-weight: bold; color: #1B1B1B; }"
        "QLabel#MrIslamPenSizeBadge { background: #1A73E8; color: white; border-radius: 11px;"
        "  padding: 2px 12px; font-size: 13px; font-weight: bold; }"
        "QLabel#MrIslamPenSizeEnd { color: #6A6A6A; font-size: 11px; }"
        "QSlider::groove:horizontal { height: 6px; background: #DCDCDC; border-radius: 3px; }"
        "QSlider::sub-page:horizontal { background: #1A73E8; border-radius: 3px; }"
        "QSlider::handle:horizontal { background: white; border: 3px solid #1A73E8; width: 16px; height: 16px;"
        "  margin: -8px 0; border-radius: 11px; }");

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(16, 12, 16, 12);
    layout->setSpacing(10);

    QHBoxLayout* head = new QHBoxLayout();
    mBadge = new QLabel(this);
    mBadge->setObjectName("MrIslamPenSizeBadge");
    mBadge->setAlignment(Qt::AlignCenter);
    mBadge->setMinimumWidth(60);
    mTitle = new QLabel(this);
    mTitle->setObjectName("MrIslamPenSizeTitle");
    mTitle->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    head->addWidget(mBadge);
    head->addStretch(1);
    head->addWidget(mTitle);
    layout->addLayout(head);

    mPreview = new UBMrIslamPenSizePreview(this);
    layout->addWidget(mPreview);

    QHBoxLayout* row = new QHBoxLayout();
    row->setSpacing(10);

    QLabel* small = new QLabel(this);
    small->setFixedSize(6, 6);
    small->setStyleSheet("background: #1B1B1B; border-radius: 3px;");
    QLabel* big = new QLabel(this);
    big->setFixedSize(20, 20);
    big->setStyleSheet("background: #1B1B1B; border-radius: 10px;");

    mSlider = new QSlider(Qt::Horizontal, this);
    mSlider->setMinimumWidth(220);
    mSlider->setMinimumHeight(30);
    mSlider->setFocusPolicy(Qt::NoFocus);

    row->addWidget(small);
    row->addWidget(mSlider, 1);
    row->addWidget(big);
    layout->addLayout(row);

    QHBoxLayout* ends = new QHBoxLayout();
    ends->setContentsMargins(18, 0, 28, 0);
    mMinLabel = new QLabel(this);
    mMinLabel->setObjectName("MrIslamPenSizeEnd");
    mMaxLabel = new QLabel(this);
    mMaxLabel->setObjectName("MrIslamPenSizeEnd");
    ends->addWidget(mMinLabel);
    ends->addStretch(1);
    ends->addWidget(mMaxLabel);
    layout->addLayout(ends);

    connect(mSlider, &QSlider::valueChanged, this, &UBMrIslamPenSizePanel::onSliderMoved);

    setFixedWidth(330);
}

void UBMrIslamPenSizePanel::setup(const QString& title, int minimum, int maximum, int value, const QColor& color)
{
    mTitle->setText(title);
    mMinLabel->setText(QString::number(minimum));
    mMaxLabel->setText(QString::number(maximum));

    const QSignalBlocker blocker(mSlider);
    mSlider->setRange(minimum, maximum);
    mSlider->setValue(qBound(minimum, value, maximum));

    QColor preview = color;
    if (preview.isValid() && preview.alpha() < 255)
        preview.setAlpha(qMax(140, preview.alpha()));   // marker colours are see-through

    mPreview->set(mSlider->value(), preview);
    mBadge->setText(QString("%1 px").arg(mSlider->value()));
}

void UBMrIslamPenSizePanel::onSliderMoved(int value)
{
    mBadge->setText(QString("%1 px").arg(value));
    mPreview->setSize(value);
    emit sizeChanged(value);
}

void UBMrIslamPenSizePanel::popupAt(const QPoint& globalPos)
{
    adjustSize();

    QScreen* screen = QGuiApplication::screenAt(globalPos);

    if (!screen)
        screen = QGuiApplication::primaryScreen();

    QPoint pos = globalPos;

    if (screen)
    {
        const QRect area = screen->availableGeometry();

        if (pos.x() + width() > area.right())
            pos.setX(area.right() - width());
        if (pos.y() + height() > area.bottom())
            pos.setY(area.bottom() - height());
        if (pos.x() < area.left())
            pos.setX(area.left());
        if (pos.y() < area.top())
            pos.setY(area.top());
    }

    move(pos);
    show();
    raise();
}
