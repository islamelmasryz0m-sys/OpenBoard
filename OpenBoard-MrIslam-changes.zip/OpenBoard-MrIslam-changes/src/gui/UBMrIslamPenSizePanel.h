/*
 * Mr. Islam El-Masry: pen size slider panel for OpenBoard.
 *
 * This file is part of OpenBoard (GPL v3).
 */

#ifndef UBMRISLAMPENSIZEPANEL_H_
#define UBMRISLAMPENSIZEPANEL_H_

#include <QColor>
#include <QFrame>
#include <QString>

class QLabel;
class QSlider;
class UBMrIslamPenSizePreview;

// Small popup under the "Pen Size" toolbar button:
// a title, the current size in px, a preview line in the current colour, and a slider.
class UBMrIslamPenSizePanel : public QFrame
{
    Q_OBJECT

public:
    explicit UBMrIslamPenSizePanel(QWidget* parent = nullptr);

    // title: "pen" or "marker" text, range of the slider, current value and colour
    void setup(const QString& title, int minimum, int maximum, int value, const QColor& color);
    void popupAt(const QPoint& globalPos);

signals:
    void sizeChanged(int size);

private slots:
    void onSliderMoved(int value);

private:
    QLabel* mTitle{nullptr};
    QLabel* mBadge{nullptr};
    QLabel* mMinLabel{nullptr};
    QLabel* mMaxLabel{nullptr};
    QSlider* mSlider{nullptr};
    UBMrIslamPenSizePreview* mPreview{nullptr};
};

#endif /* UBMRISLAMPENSIZEPANEL_H_ */
