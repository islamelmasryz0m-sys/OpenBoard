/*
 * Mr. Islam El-Masry: emoji and sticker panel for OpenBoard.
 *
 * This file is part of OpenBoard (GPL v3).
 *
 * Emoji pictures: Noto Emoji 3D by Google (Apache License 2.0),
 * copied next to the program at build time (folder "emoji").
 */

#include "UBMrIslamStickerPanel.h"

#include <QApplication>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHash>
#include <QHBoxLayout>
#include <QIcon>
#include <QLineEdit>
#include <QListWidget>
#include <QScreen>
#include <QShowEvent>
#include <QStackedLayout>
#include <QTabBar>
#include <QTabWidget>
#include <QTextStream>
#include <QToolButton>
#include <QUrl>
#include <QVBoxLayout>

#include "core/UBSettings.h"

namespace
{
    const int kEmojiIcon = 44;
    const int kEmojiCell = 54;
    const int kStickerIcon = 96;
    const int kStickerCell = 108;
    const int kMaxRecent = 32;
    const char* const kRecentKey = "Board/MrIslamRecentStickers";

    QString emojiDirectory()
    {
        return QApplication::applicationDirPath() + "/emoji";
    }

    QString builtInStickerDirectory()
    {
        return QApplication::applicationDirPath() + "/stickers";
    }

    QString emojiFile(const QString& name)
    {
        return emojiDirectory() + "/" + name;
    }
}

UBMrIslamStickerPanel::UBMrIslamStickerPanel(QWidget* parent)
    : QFrame(parent, Qt::Popup | Qt::FramelessWindowHint)
{
    setObjectName("MrIslamStickerPanel");
    setFrameShape(QFrame::StyledPanel);
    setStyleSheet(
        "QFrame#MrIslamStickerPanel { background: #FFFFFF; border: 1px solid #B9B9B9; border-radius: 8px; }"
        "QLineEdit { padding: 5px 8px; border: 1px solid #C8C8C8; border-radius: 6px; font-size: 13px; }"
        "QListWidget { border: none; background: #FFFFFF; }"
        "QListWidget::item { border-radius: 6px; }"
        "QListWidget::item:hover { background: #E8F1FF; }"
        "QListWidget::item:selected { background: #D3E5FF; }"
        "QTabWidget::pane { border: none; border-top: 1px solid #E2E2E2; }"
        "QTabBar::tab { padding: 4px 6px; border: none; background: transparent; }"
        "QTabBar::tab:selected { border-bottom: 3px solid #1A73E8; }"
        "QTabBar::tab:hover { background: #F1F1F1; }");

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(8, 8, 8, 8);
    layout->setSpacing(6);

    QHBoxLayout* top = new QHBoxLayout();
    top->setSpacing(6);

    mSearch = new QLineEdit(this);
    mSearch->setPlaceholderText(tr("Search emoji (English)..."));
    mSearch->setClearButtonEnabled(true);
    top->addWidget(mSearch, 1);

    QToolButton* folderButton = new QToolButton(this);
    folderButton->setText(tr("My Stickers Folder"));
    folderButton->setToolTip(tr("Put your own sticker pictures (PNG / WEBP / JPG) in this folder, they appear in the Stickers tab."));
    folderButton->setAutoRaise(true);
    top->addWidget(folderButton);

    layout->addLayout(top);

    QWidget* stackHost = new QWidget(this);
    QStackedLayout* stack = new QStackedLayout(stackHost);
    stack->setContentsMargins(0, 0, 0, 0);

    mTabs = new QTabWidget(stackHost);
    mTabs->setDocumentMode(true);
    mTabs->setUsesScrollButtons(false);
    mTabs->setIconSize(QSize(24, 24));
    mTabs->tabBar()->setExpanding(true);
    stack->addWidget(mTabs);

    mSearchList = createList(false);
    stack->addWidget(mSearchList);

    layout->addWidget(stackHost, 1);

    // tabs like the WhatsApp emoji keyboard (+ Recent and the teacher's Stickers)
    auto addTab = [this](const QString& title, const QString& iconName, bool recent = false, bool stickers = false)
    {
        Tab tab;
        tab.title = title;
        tab.iconFile = emojiFile(iconName);
        tab.isRecent = recent;
        tab.isStickers = stickers;
        tab.list = createList(stickers);
        mTabData.append(tab);

        const int index = mTabs->addTab(tab.list, QIcon(tab.iconFile), QString());
        mTabs->setTabToolTip(index, title);
    };

    addTab(tr("Recent"), "emoji_u1f552.png", true);
    addTab(tr("Stickers"), "emoji_u1f31f.png", false, true);
    addTab(tr("Smileys & People"), "emoji_u1f600.png");
    addTab(tr("Animals & Nature"), "emoji_u1f43b.png");
    addTab(tr("Food & Drink"), "emoji_u1f354.png");
    addTab(tr("Activity"), "emoji_u26bd.png");
    addTab(tr("Travel & Places"), "emoji_u1f697.png");
    addTab(tr("Objects"), "emoji_u1f4a1.png");
    addTab(tr("Symbols"), "emoji_u1f523.png");
    addTab(tr("Flags"), "emoji_u1f3c1.png");

    connect(mTabs, &QTabWidget::currentChanged, this, &UBMrIslamStickerPanel::onTabChanged);
    connect(mSearch, &QLineEdit::textChanged, this, &UBMrIslamStickerPanel::onSearchChanged);
    connect(mSearchList, &QListWidget::itemClicked, this, &UBMrIslamStickerPanel::onItemClicked);

    connect(folderButton, &QToolButton::clicked, this, [this]()
    {
        const QString dir = userStickerDirectory();
        QDir().mkpath(dir);
        hide();
        QDesktopServices::openUrl(QUrl::fromLocalFile(dir));
    });

    resize(476, 430);
}

QString UBMrIslamStickerPanel::userStickerDirectory()
{
    return UBSettings::userDataDirectory() + "/stickers";
}

QListWidget* UBMrIslamStickerPanel::createList(bool bigCells)
{
    QListWidget* list = new QListWidget(this);
    list->setViewMode(QListView::IconMode);
    list->setMovement(QListView::Static);
    list->setResizeMode(QListView::Adjust);
    list->setWrapping(true);
    list->setUniformItemSizes(true);
    list->setSelectionMode(QAbstractItemView::SingleSelection);
    list->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    list->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    list->setMouseTracking(true);
    list->setFocusPolicy(Qt::NoFocus);
    list->setIconSize(bigCells ? QSize(kStickerIcon, kStickerIcon) : QSize(kEmojiIcon, kEmojiIcon));
    list->setGridSize(bigCells ? QSize(kStickerCell, kStickerCell) : QSize(kEmojiCell, kEmojiCell));
    list->setSpacing(0);

    connect(list, &QListWidget::itemClicked, this, &UBMrIslamStickerPanel::onItemClicked);
    return list;
}

void UBMrIslamStickerPanel::fillList(QListWidget* list, const QList<Entry>& entries)
{
    list->clear();

    for (const Entry& entry : entries)
    {
        // QIcon loads the picture only when it is shown, so big tabs open quickly
        QListWidgetItem* item = new QListWidgetItem(QIcon(entry.file), QString(), list);
        item->setData(Qt::UserRole, entry.file);
        item->setToolTip(entry.name);
        item->setSizeHint(list->gridSize());
    }

    list->scrollToTop();
}

void UBMrIslamStickerPanel::loadEmojiManifest()
{
    if (mLoaded)
        return;

    mLoaded = true;

    // manifest.txt: one emoji per line, "group <TAB> file <TAB> name", already in WhatsApp-like order
    QFile file(emojiDirectory() + "/manifest.txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
#if (QT_VERSION < QT_VERSION_CHECK(6, 0, 0))
    in.setCodec("UTF-8");
#endif

    while (!in.atEnd())
    {
        const QStringList parts = in.readLine().split('\t');

        if (parts.size() < 3)
            continue;

        const QString group = parts.at(0);
        Entry entry;
        entry.file = emojiFile(parts.at(1));
        entry.name = parts.at(2);

        if (!QFileInfo::exists(entry.file))
            continue;

        int tab = -1;

        if (group == "Smileys & Emotion" || group == "People & Body")
            tab = 2;
        else if (group == "Animals & Nature")
            tab = 3;
        else if (group == "Food & Drink")
            tab = 4;
        else if (group == "Activities")
            tab = 5;
        else if (group == "Travel & Places")
            tab = 6;
        else if (group == "Objects")
            tab = 7;
        else if (group == "Symbols")
            tab = 8;
        else if (group == "Flags")
            tab = 9;

        if (tab < 0)
            continue;

        mTabData[tab].entries.append(entry);
        mAllEmoji.append(entry);
    }
}

QList<UBMrIslamStickerPanel::Entry> UBMrIslamStickerPanel::loadStickers() const
{
    QList<Entry> stickers;
    const QStringList filters { "*.png", "*.webp", "*.jpg", "*.jpeg", "*.gif", "*.bmp" };

    for (const QString& dirPath : { builtInStickerDirectory(), userStickerDirectory() })
    {
        QDir dir(dirPath);

        if (!dir.exists())
            continue;

        // optional names.txt: "file name <TAB> display name" (the built-in stickers have plain file names)
        QHash<QString, QString> names;
        QFile namesFile(dir.filePath("names.txt"));

        if (namesFile.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QTextStream in(&namesFile);
#if (QT_VERSION < QT_VERSION_CHECK(6, 0, 0))
            in.setCodec("UTF-8");
#endif
            while (!in.atEnd())
            {
                const QStringList parts = in.readLine().split('\t');

                if (parts.size() >= 2)
                    names.insert(parts.at(0).trimmed(), parts.at(1).trimmed());
            }
        }

        const QFileInfoList files = dir.entryInfoList(filters, QDir::Files, QDir::Name | QDir::IgnoreCase);

        for (const QFileInfo& info : files)
        {
            Entry entry;
            entry.file = info.absoluteFilePath();
            entry.name = names.value(info.fileName(), info.completeBaseName());
            stickers.append(entry);
        }
    }

    return stickers;
}

QList<UBMrIslamStickerPanel::Entry> UBMrIslamStickerPanel::recentEntries() const
{
    QList<Entry> recent;
    const QStringList files = UBSettings::settings()->value(kRecentKey).toStringList();

    for (const QString& path : files)
    {
        if (!QFileInfo::exists(path))
            continue;

        Entry entry;
        entry.file = path;
        entry.name = QFileInfo(path).completeBaseName();
        recent.append(entry);
    }

    return recent;
}

void UBMrIslamStickerPanel::rememberRecent(const QString& file)
{
    QStringList files = UBSettings::settings()->value(kRecentKey).toStringList();
    files.removeAll(file);
    files.prepend(file);

    while (files.size() > kMaxRecent)
        files.removeLast();

    UBSettings::settings()->setValue(kRecentKey, files);

    // the Recent tab is rebuilt the next time it is shown
    mTabData[0].filled = false;
}

void UBMrIslamStickerPanel::fillTab(int index)
{
    if (index < 0 || index >= mTabData.size())
        return;

    Tab& tab = mTabData[index];

    if (tab.filled)
        return;

    if (tab.isRecent)
        fillList(tab.list, recentEntries());
    else if (tab.isStickers)
        fillList(tab.list, loadStickers());
    else
        fillList(tab.list, tab.entries);

    tab.filled = true;
}

void UBMrIslamStickerPanel::onTabChanged(int index)
{
    fillTab(index);
}

void UBMrIslamStickerPanel::showEvent(QShowEvent* event)
{
    loadEmojiManifest();

    // new sticker files may have been added to the folder
    mTabData[1].filled = false;

    if (!mSearch->text().isEmpty())
        mSearch->clear();

    // open on Recent when something was used before, otherwise on Smileys
    const int startTab = recentEntries().isEmpty() ? 2 : 0;

    if (mTabs->currentIndex() != startTab)
        mTabs->setCurrentIndex(startTab);  // fills the tab through onTabChanged

    fillTab(mTabs->currentIndex());

    QFrame::showEvent(event);
    mSearch->setFocus();
}

void UBMrIslamStickerPanel::onSearchChanged(const QString& text)
{
    QStackedLayout* stack = qobject_cast<QStackedLayout*>(mTabs->parentWidget()->layout());
    const QString needle = text.trimmed();

    if (needle.isEmpty())
    {
        if (stack)
            stack->setCurrentWidget(mTabs);
        return;
    }

    QList<Entry> found;

    for (const Entry& entry : loadStickers())
    {
        if (entry.name.contains(needle, Qt::CaseInsensitive))
            found.append(entry);
    }

    for (const Entry& entry : mAllEmoji)
    {
        if (entry.name.contains(needle, Qt::CaseInsensitive))
            found.append(entry);
    }

    fillList(mSearchList, found);

    if (stack)
        stack->setCurrentWidget(mSearchList);
}

void UBMrIslamStickerPanel::onItemClicked(QListWidgetItem* item)
{
    if (!item)
        return;

    const QString file = item->data(Qt::UserRole).toString();

    if (file.isEmpty())
        return;

    rememberRecent(file);
    hide();
    emit picked(file);
}

void UBMrIslamStickerPanel::popupAt(const QPoint& globalPos)
{
    QScreen* screen = QGuiApplication::screenAt(globalPos);

    if (!screen)
        screen = QGuiApplication::primaryScreen();

    QPoint pos = globalPos;

    if (screen)
    {
        const QRect area = screen->availableGeometry();

        if (pos.x() + width() > area.right())
            pos.setX(area.right() - width());
        if (pos.y() + height() > area.bottom())
            pos.setY(area.bottom() - height());
        if (pos.x() < area.left())
            pos.setX(area.left());
        if (pos.y() < area.top())
            pos.setY(area.top());
    }

    move(pos);
    show();
    raise();
    activateWindow();
}
