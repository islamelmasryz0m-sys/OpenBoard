/*
 * Mr. Islam El-Masry: emoji and sticker panel for OpenBoard.
 *
 * This file is part of OpenBoard (GPL v3).
 */

#ifndef UBMRISLAMSTICKERPANEL_H_
#define UBMRISLAMSTICKERPANEL_H_

#include <QFrame>
#include <QList>
#include <QString>
#include <QStringList>

class QLineEdit;
class QListWidget;
class QListWidgetItem;
class QTabWidget;

// A popup window (like the WhatsApp emoji keyboard) with tabs:
// Recent, the 8 emoji groups, and Stickers.
// Clicking a picture emits picked() with the path of the image file.
class UBMrIslamStickerPanel : public QFrame
{
    Q_OBJECT

public:
    explicit UBMrIslamStickerPanel(QWidget* parent = nullptr);

    // show the panel under (or above) the given global point, fully on screen
    void popupAt(const QPoint& globalPos);

    // folder for the teacher's own stickers (can be filled without rebuilding the program)
    static QString userStickerDirectory();

signals:
    void picked(const QString& imageFile);

protected:
    void showEvent(QShowEvent* event) override;

private slots:
    void onTabChanged(int index);
    void onItemClicked(QListWidgetItem* item);
    void onSearchChanged(const QString& text);

private:
    struct Entry
    {
        QString file;   // absolute path of the picture
        QString name;   // English name, used for searching
    };

    struct Tab
    {
        QString title;
        QString iconFile;
        QList<Entry> entries;
        QListWidget* list{nullptr};
        bool filled{false};
        bool isRecent{false};
        bool isStickers{false};
    };

    void loadEmojiManifest();
    QList<Entry> loadStickers() const;
    QList<Entry> recentEntries() const;
    void rememberRecent(const QString& file);

    QListWidget* createList(bool bigCells);
    void fillList(QListWidget* list, const QList<Entry>& entries);
    void fillTab(int index);

    QLineEdit* mSearch{nullptr};
    QTabWidget* mTabs{nullptr};
    QListWidget* mSearchList{nullptr};
    QList<Tab> mTabData;
    QList<Entry> mAllEmoji;
    bool mLoaded{false};
};

#endif /* UBMRISLAMSTICKERPANEL_H_ */
