/*
 * Copyright (C) 2026 Mr. Islam Elmasry customization of OpenBoard
 *
 * This file is part of OpenBoard.
 *
 * OpenBoard is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License,
 * with a specific linking exception for the OpenSSL project's
 * "OpenSSL" library (or with modified versions of it that use the
 * same license as the "OpenSSL" library).
 *
 * OpenBoard is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenBoard. If not, see <http://www.gnu.org/licenses/>.
 */

#include "UBPenCursorFactory.h"

#include <QGuiApplication>
#include <QPainter>
#include <QPainterPath>
#include <QPolygonF>
#include <QVector>

#include <functional>

namespace
{
    // One filled part of a pen, in "pen coordinates": the tip is at (0,0)
    // and the pen body goes up (negative y), about 58 units long.
    struct Part
    {
        QPainterPath path;
        QColor fill;
    };

    typedef QVector<Part> Pen;

    Part poly(std::initializer_list<QPointF> points, const QColor& fill)
    {
        QPainterPath path;
        path.addPolygon(QPolygonF(QVector<QPointF>(points)));
        path.closeSubpath();
        return { path, fill };
    }

    Part rect(qreal x, qreal y, qreal w, qreal h, const QColor& fill, qreal r = 0)
    {
        QPainterPath path;

        if (r > 0)
            path.addRoundedRect(QRectF(x, y, w, h), r, r);
        else
            path.addRect(QRectF(x, y, w, h));

        return { path, fill };
    }

    QColor opaque(QColor c)
    {
        c.setAlpha(255);
        return c;
    }

    Pen pencil()
    {
        return {
            poly({ {0, 0}, {-2, -6}, {2, -6} }, QColor("#333333")),
            poly({ {-2, -6}, {2, -6}, {5, -15}, {-5, -15} }, QColor("#F3C892")),
            rect(-5, -48, 10, 33, QColor("#FFB800")),
            rect(-1.5, -48, 3, 33, QColor("#E89A00")),
            rect(-5, -52, 10, 4, QColor("#B8B8B8")),
            rect(-5, -58, 10, 6, QColor("#FF6B8A"), 2)
        };
    }

    Pen fountain()
    {
        return {
            poly({ {0, 0}, {-4, -10}, {-5, -16}, {5, -16}, {4, -10} }, QColor("#E5A800")),
            rect(-0.4, -12, 0.8, 10, QColor("#7A5A10")),
            rect(-5, -22, 10, 6, QColor("#111111")),
            rect(-5.5, -56, 11, 34, QColor("#0F1F4A"), 3),
            rect(-5.5, -38, 11, 2, QColor("#E5A800"))
        };
    }

    Pen stylus()
    {
        return {
            poly({ {0, 0}, {-1.4, -3.5}, {1.4, -3.5} }, QColor("#333333")),
            poly({ {-1.4, -3.5}, {1.4, -3.5}, {5, -14}, {-5, -14} }, QColor("#E4E4E4")),
            rect(-5, -57, 10, 43, QColor("#FFFFFF"), 3),
            rect(-5, -30, 10, 1, QColor("#C8C8C8"))
        };
    }

    Pen inkTip(const QColor& ink)
    {
        return {
            poly({ {0, 0}, {-1.6, -4}, {1.6, -4} }, ink),
            poly({ {-1.6, -4}, {1.6, -4}, {5, -14}, {-5, -14} }, QColor("#2A2A2A")),
            rect(-5, -17, 10, 3, ink),
            rect(-5, -57, 10, 40, QColor("#1E1E1E"), 3)
        };
    }

    Pen boardMarker(const QColor& ink)
    {
        return {
            poly({ {-1.5, 0}, {1.5, 0}, {3, -5}, {-3, -5} }, ink),
            rect(-5, -11, 10, 6, QColor("#D6D6D6")),
            rect(-6.5, -47, 13, 36, QColor("#F7F7F7"), 2),
            rect(-7, -57, 14, 10, ink, 2)
        };
    }

    Pen wideHighlighter(const QColor& ink)
    {
        return {
            poly({ {-4, 0}, {4, -2}, {5, -7}, {-5, -7} }, ink),
            rect(-6, -12, 12, 5, QColor("#222222")),
            rect(-7, -46, 14, 34, ink, 3),
            rect(-7, -40, 14, 10, QColor("#FFFFFF")),
            rect(-7.5, -56, 15, 10, QColor("#222222"), 3)
        };
    }

    Pen elegantHighlighter(const QColor& ink)
    {
        return {
            poly({ {-2, 0}, {2, 0}, {3.5, -6}, {-3.5, -6} }, ink),
            rect(-5, -10, 10, 4, QColor("#444444")),
            rect(-6, -50, 12, 40, QColor("#1E1E1E"), 5),
            rect(-6, -30, 12, 4, ink),
            rect(-6.5, -58, 13, 9, ink, 4)
        };
    }

    struct Style
    {
        const char* name;
        std::function<Pen(const QColor&)> pen;
        bool halo;
    };

    const QVector<Style>& penStyles()
    {
        static const QVector<Style> styles = {
            { "Pencil - قلم رصاص", [](const QColor&) { return pencil(); }, false },
            { "Fountain pen - قلم حبر فاخر", [](const QColor&) { return fountain(); }, false },
            { "Stylus - ستايلس", [](const QColor&) { return stylus(); }, false },
            { "Ink tip - سن بلون الحبر", [](const QColor& c) { return inkTip(c); }, false },
            { "Board marker - ماركر سبورة", [](const QColor& c) { return boardMarker(c); }, false },
            { "Focus halo - قلم بهالة تركيز", [](const QColor&) { return pencil(); }, true }
        };
        return styles;
    }

    const QVector<Style>& markerStyles()
    {
        static const QVector<Style> styles = {
            { "Wide highlighter - هايلايتر عريض", [](const QColor& c) { return wideHighlighter(c); }, false },
            { "Elegant highlighter - هايلايتر أنيق", [](const QColor& c) { return elegantHighlighter(c); }, false },
            { "Highlighter with halo - هايلايتر بهالة", [](const QColor& c) { return wideHighlighter(c); }, true }
        };
        return styles;
    }

    // Tip position (hot spot) inside the 48x48 cursor.
    // Mr. Islam: the tip is in the top-left corner, like the normal Windows arrow.
    // A hot spot of (2,2) stays right even if Windows scales or ignores it,
    // which keeps the pen tip exactly on the ink.
    QPointF tipPosition(bool halo)
    {
        Q_UNUSED(halo);
        return QPointF(2, 2);
    }

    void paintPen(QPainter& painter, const Pen& pen, bool halo)
    {
        const QPointF tip = tipPosition(halo);

        painter.setRenderHint(QPainter::Antialiasing, true);

        if (halo)
        {
            QColor haloFill("#FFE000");
            haloFill.setAlphaF(0.4);
            painter.setBrush(haloFill);
            painter.setPen(QPen(QColor("#FFB800"), 1.3));
            painter.drawEllipse(tip, 10, 10);
        }

        painter.save();
        painter.translate(tip);
        painter.rotate(135); // body goes down-right from the tip

        if (halo)
            painter.scale(0.8, 0.8);
        else
            painter.scale(0.92, 0.92); // keeps the longest pens inside the 48x48 picture

        // white outline first so the pen stays visible on dark boards
        for (const Part& part : pen)
        {
            painter.setPen(QPen(Qt::white, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            painter.setBrush(part.fill);
            painter.drawPath(part.path);
        }

        // then the parts with a thin dark outline
        for (const Part& part : pen)
        {
            painter.setPen(QPen(QColor("#111111"), 0.7, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            painter.setBrush(part.fill);
            painter.drawPath(part.path);
        }

        painter.restore();
    }

    QPixmap render(const Style& style, const QColor& ink, int size, qreal dpr)
    {
        const int pixels = qMax(1, qRound(size * dpr));
        QPixmap pixmap(pixels, pixels);
        pixmap.fill(Qt::transparent);

        {
            QPainter painter(&pixmap);
            painter.scale(pixels / qreal(UBPenCursorFactory::cursorSize),
                          pixels / qreal(UBPenCursorFactory::cursorSize));
            paintPen(painter, style.pen(opaque(ink)), style.halo);
        }

        pixmap.setDevicePixelRatio(dpr);
        return pixmap;
    }

    qreal cursorDevicePixelRatio()
    {
        // Mr. Islam: render at exactly the screen's scale. A 2x picture on a 100% screen
        // made Windows place the pen tip about 40 pixels below the real pen position.
        const qreal dpr = qApp ? qApp->devicePixelRatio() : 1.0;
        return dpr > 0 ? dpr : 1.0;
    }

    QCursor makeCursor(const Style& style, const QColor& ink)
    {
        const qreal dpr = cursorDevicePixelRatio();
        const QPixmap pixmap = render(style, ink, UBPenCursorFactory::cursorSize, dpr);
        const QPointF tip = tipPosition(style.halo);

        // hot spot in logical pixels (Qt 6), matching the picture drawn at the screen's scale
        return QCursor(pixmap, qRound(tip.x()), qRound(tip.y()));
    }

    int clampStyle(int style, int count)
    {
        return (style >= 0 && style < count) ? style : 0;
    }
}

int UBPenCursorFactory::penStyleCount()
{
    return penStyles().size();
}

QString UBPenCursorFactory::penStyleName(int style)
{
    return QString::fromUtf8(penStyles().at(clampStyle(style, penStyleCount())).name);
}

int UBPenCursorFactory::markerStyleCount()
{
    return markerStyles().size();
}

QString UBPenCursorFactory::markerStyleName(int style)
{
    return QString::fromUtf8(markerStyles().at(clampStyle(style, markerStyleCount())).name);
}

QCursor UBPenCursorFactory::penCursor(int style, const QColor& ink)
{
    return makeCursor(penStyles().at(clampStyle(style, penStyleCount())), ink);
}

QCursor UBPenCursorFactory::markerCursor(int style, const QColor& ink)
{
    return makeCursor(markerStyles().at(clampStyle(style, markerStyleCount())), ink);
}

QPixmap UBPenCursorFactory::penPreview(int style, const QColor& ink, int size)
{
    return render(penStyles().at(clampStyle(style, penStyleCount())), ink, size, cursorDevicePixelRatio());
}

QPixmap UBPenCursorFactory::markerPreview(int style, const QColor& ink, int size)
{
    return render(markerStyles().at(clampStyle(style, markerStyleCount())), ink, size, cursorDevicePixelRatio());
}
