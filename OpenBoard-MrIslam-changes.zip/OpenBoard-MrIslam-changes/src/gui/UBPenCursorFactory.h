/*
 * Copyright (C) 2026 Mr. Islam Elmasry customization of OpenBoard
 *
 * This file is part of OpenBoard.
 *
 * OpenBoard is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License,
 * with a specific linking exception for the OpenSSL project's
 * "OpenSSL" library (or with modified versions of it that use the
 * same license as the "OpenSSL" library).
 *
 * OpenBoard is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenBoard. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef UBPENCURSORFACTORY_H_
#define UBPENCURSORFACTORY_H_

#include <QColor>
#include <QCursor>
#include <QPixmap>
#include <QString>

/**
 * Draws the pen-shaped and highlighter-shaped mouse cursors.
 *
 * The cursors are drawn with QPainter (not loaded from image files) so the
 * "ink" styles can show the colour that is currently selected.
 * The tip of every cursor is its hot spot, so the line starts exactly
 * where the pen tip touches the board.
 */
namespace UBPenCursorFactory
{
    // logical size of the cursor in device independent pixels
    const int cursorSize = 48;

    int penStyleCount();
    QString penStyleName(int style);

    int markerStyleCount();
    QString markerStyleName(int style);

    QCursor penCursor(int style, const QColor& ink);
    QCursor markerCursor(int style, const QColor& ink);

    // icon used in the toolbar menu
    QPixmap penPreview(int style, const QColor& ink, int size);
    QPixmap markerPreview(int style, const QColor& ink, int size);
}

#endif /* UBPENCURSORFACTORY_H_ */
